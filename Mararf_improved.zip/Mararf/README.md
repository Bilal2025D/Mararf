# مشروع Mararf - دليل المستخدم والمطور

## نظرة عامة

مشروع Mararf هو منصة تعليمية متكاملة تم تطويرها باستخدام React وTypeScript مع Vite كأداة بناء، ويستخدم مكتبات shadcn-ui وTailwind CSS للواجهة. يوفر المشروع العديد من الميزات مثل إدارة الأعضاء، تسجيل الحضور، إدارة الأنشطة، الرسائل، التقارير، وغيرها.

## الميزات الرئيسية

- **واجهة مستخدم متعددة اللغات**: دعم كامل للغة العربية والإنجليزية مع إمكانية التبديل بينهما بسهولة.
- **وضع الظلام (Dark Mode)**: دعم وضع الظلام لتحسين تجربة المستخدم وتقليل إجهاد العين.
- **تصميم متجاوب**: واجهة مستخدم متجاوبة تعمل بشكل جيد على جميع أحجام الشاشات.
- **أداء محسن**: استخدام تقنيات مثل Code Splitting وMemoization لتحسين أداء التطبيق.
- **أمان محسن**: تحقق من المدخلات باستخدام Zod وتحسين أمان Supabase.

## متطلبات النظام

- Node.js (الإصدار 18 أو أحدث)
- npm (الإصدار 8 أو أحدث)

## التثبيت والإعداد

1. استنساخ المستودع:
```bash
git clone https://github.com/Bilal2025D/Mararf.git
```

2. الانتقال إلى مجلد المشروع:
```bash
cd Mararf
```

3. تثبيت التبعيات:
```bash
npm install
```

4. إنشاء ملف `.env` في المجلد الرئيسي وإضافة متغيرات البيئة:
```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

5. تشغيل التطبيق في وضع التطوير:
```bash
npm run dev
```

## هيكل المشروع

```
Mararf/
├── public/             # الملفات العامة
├── src/                # كود المصدر
│   ├── components/     # مكونات React
│   │   ├── common/     # مكونات مشتركة
│   │   ├── features/   # مكونات خاصة بميزات معينة
│   │   ├── layout/     # مكونات التخطيط
│   │   └── ui/         # مكونات واجهة المستخدم
│   ├── contexts_merged/ # سياقات React
│   ├── hooks/          # React Hooks مخصصة
│   ├── integrations/   # تكاملات مع خدمات خارجية
│   │   └── supabase/   # تكامل مع Supabase
│   ├── lib/            # مكتبات وأدوات مساعدة
│   ├── pages/          # صفحات التطبيق
│   ├── styles/         # أنماط CSS
│   ├── App.tsx         # مكون التطبيق الرئيسي
│   ├── main.tsx        # نقطة الدخول
│   └── types.ts        # تعريفات TypeScript
├── .gitignore          # ملفات مستثناة من Git
├── index.html          # ملف HTML الرئيسي
├── package.json        # تبعيات المشروع
├── tsconfig.json       # إعدادات TypeScript
└── vite.config.ts      # إعدادات Vite
```

## الميزات المضافة والتحسينات

### 1. تحسينات الهيكل
- دمج مجلدي `context` و`contexts` في مجلد واحد `contexts_merged`
- إعادة تنظيم المكونات في هيكل أكثر وضوحاً (common, layout, features)

### 2. تحسينات الكود
- تحسين استخدام TypeScript وتحديد الأنواع بشكل أفضل
- استبدال استخدام document API المباشر بـ React Hooks
- تطبيق مبدأ الفصل بين المسؤوليات

### 3. تحسينات الأداء
- تطبيق Code Splitting باستخدام React.lazy و Suspense
- تحسين استيراد المكتبات
- تطبيق Memoization لتحسين الأداء
- تحسين التعامل مع الصور

### 4. تحسينات الأمان
- إضافة التحقق من المدخلات باستخدام Zod
- تحسين أمان Supabase

### 5. تحسينات واجهة المستخدم
- تطبيق نظام تعدد اللغات
- إضافة وضع الظلام (Dark Mode)
- تحسين تجربة المستخدم على الأجهزة المحمولة

## استخدام تعدد اللغات

يمكن استخدام وظيفة الترجمة في أي مكون باستخدام hook المخصص `useLanguage`:

```tsx
import { useLanguage } from "@/contexts_merged/LanguageContext";

function MyComponent() {
  const { t, language, setLanguage, dir } = useLanguage();
  
  return (
    <div dir={dir}>
      <h1>{t('app.title')}</h1>
      <p>{t('app.description')}</p>
      <button onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}>
        {t('settings.language')}
      </button>
    </div>
  );
}
```

## استخدام وضع الظلام

يمكن استخدام وظيفة وضع الظلام في أي مكون باستخدام hook المخصص `useTheme`:

```tsx
import { useTheme } from "@/contexts_merged/ThemeContext";

function MyComponent() {
  const { theme, setTheme, isDark } = useTheme();
  
  return (
    <div className={isDark ? 'bg-gray-900 text-white' : 'bg-white text-gray-900'}>
      <h1>عنوان المكون</h1>
      <button onClick={() => setTheme(isDark ? 'light' : 'dark')}>
        تبديل السمة
      </button>
    </div>
  );
}
```

## التحقق من المدخلات

يمكن استخدام وظيفة التحقق من المدخلات في أي نموذج باستخدام الدالة `validateData`:

```tsx
import { validateData, userSchema } from "@/lib/validation";

function LoginForm() {
  const handleSubmit = (data) => {
    const validation = validateData(userSchema, data);
    
    if (validation.success) {
      // إرسال البيانات إلى الخادم
    } else {
      // عرض رسائل الخطأ
    }
  };
  
  return (
    // نموذج تسجيل الدخول
  );
}
```

## التعامل مع Supabase

يمكن استخدام وظائف Supabase الآمنة للتعامل مع قاعدة البيانات:

```tsx
import { safeInsert, safeSelect, safeUpdate, safeDelete } from "@/integrations/supabase/supabaseClient";
import { userSchema } from "@/lib/validation";

// إدراج بيانات
const insertUser = async (userData) => {
  const result = await safeInsert('users', userSchema, userData);
  return result;
};

// استرجاع بيانات
const getUsers = async () => {
  const result = await safeSelect('users');
  return result;
};

// تحديث بيانات
const updateUser = async (userId, userData) => {
  const result = await safeUpdate('users', userSchema, userId, userData);
  return result;
};

// حذف بيانات
const deleteUser = async (userId) => {
  const result = await safeDelete('users', userId);
  return result;
};
```

## البناء للإنتاج

لبناء التطبيق للإنتاج، قم بتنفيذ الأمر التالي:

```bash
npm run build
```

سيتم إنشاء ملفات البناء في مجلد `dist` والتي يمكن نشرها على أي خادم ويب.

## المساهمة في المشروع

1. قم بعمل fork للمشروع
2. قم بإنشاء فرع جديد (`git checkout -b feature/amazing-feature`)
3. قم بإجراء التغييرات المطلوبة
4. قم بعمل commit للتغييرات (`git commit -m 'Add some amazing feature'`)
5. قم بدفع التغييرات إلى الفرع (`git push origin feature/amazing-feature`)
6. قم بفتح طلب سحب (Pull Request)

## الترخيص

هذا المشروع مرخص تحت [MIT License](LICENSE).
