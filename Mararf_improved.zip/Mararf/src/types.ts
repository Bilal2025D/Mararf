/**
 * تعريفات الأنواع الرئيسية للتطبيق
 */

export interface Activity {
  id: number;
  title: string;
  date: string;
  time: string;
  location: string;
}

export interface AttendanceRecord {
  id: number;
  name: string;
  status: "present" | "absent" | "late";
  type: "عضو" | "طالب" | "teacher" | "student";
}

export interface Member {
  id: string;
  name: string;
  email: string | null;
  app_role: string;
  phone?: string;
  status?: string;
  type?: string;
}

/**
 * واجهة لبيانات الطالب
 */
export interface Student {
  id: string;
  name: string;
  group?: string;
  grade?: string;
  parent_phone?: string;
  attendance_record?: AttendanceRecord[];
}

/**
 * واجهة لمجموعات الطلاب
 */
export interface StudentGroup {
  id: string;
  name: string;
  students: Student[];
}

/**
 * واجهة لبيانات المستخدم
 */
export interface User {
  id: string;
  name: string;
  email: string;
  role: "admin" | "teacher" | "student" | "parent";
}

/**
 * واجهة لإعدادات التطبيق
 */
export interface AppSettings {
  theme: "light" | "dark" | "system";
  language: "ar" | "en";
  notifications: boolean;
}
