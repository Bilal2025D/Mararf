/**
 * مكون React لتحسين استخدام document API
 * يوفر واجهة برمجية أفضل للتعامل مع viewport
 */
import { useEffect, useState } from 'react';

interface UseViewportReturn {
  setViewport: () => void;
  enableSmoothScrolling: () => void;
  disableOverscrollBehavior: () => void;
  setTouchAction: (action: string) => void;
}

export function useViewport(): UseViewportReturn {
  const [isInitialized, setIsInitialized] = useState(false);

  // تهيئة الـ viewport
  const setViewport = () => {
    const viewport = document.querySelector("meta[name=viewport]");
    if (viewport) {
      viewport.setAttribute("content", "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover");
    } else {
      const meta = document.createElement("meta");
      meta.name = "viewport";
      meta.content = "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover";
      document.head.appendChild(meta);
    }
  };

  // تمكين التمرير الناعم
  const enableSmoothScrolling = () => {
    document.documentElement.style.scrollBehavior = "smooth";
  };

  // منع السحب للتحديث
  const disableOverscrollBehavior = () => {
    document.body.style.overscrollBehavior = "none";
  };

  // ضبط سلوك اللمس
  const setTouchAction = (action: string) => {
    document.documentElement.style.touchAction = action;
  };

  // تهيئة الـ viewport عند تحميل المكون
  useEffect(() => {
    if (!isInitialized) {
      setViewport();
      enableSmoothScrolling();
      disableOverscrollBehavior();
      setTouchAction("manipulation");
      setIsInitialized(true);
    }
  }, [isInitialized]);

  return {
    setViewport,
    enableSmoothScrolling,
    disableOverscrollBehavior,
    setTouchAction
  };
}
