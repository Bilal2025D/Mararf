/**
 * مكون React لتطبيق Memoization وتحسين الأداء
 * يوفر واجهة لتخزين نتائج العمليات المكلفة حسابياً
 */
import { useMemo, useCallback, useState, useEffect } from 'react';

/**
 * Hook مخصص لتخزين نتائج العمليات المكلفة حسابياً
 * @param callback الدالة المراد تخزين نتائجها
 * @param dependencies المتغيرات التي تؤثر على نتيجة الدالة
 * @returns نتيجة الدالة المخزنة
 */
export function useMemoized<T>(callback: () => T, dependencies: React.DependencyList): T {
  return useMemo(callback, dependencies);
}

/**
 * Hook مخصص لتخزين الدوال وتجنب إعادة إنشائها
 * @param callback الدالة المراد تخزينها
 * @param dependencies المتغيرات التي تؤثر على الدالة
 * @returns الدالة المخزنة
 */
export function useStableCallback<T extends (...args: any[]) => any>(
  callback: T,
  dependencies: React.DependencyList
): T {
  return useCallback(callback, dependencies);
}

/**
 * Hook مخصص لتأخير تنفيذ العمليات المكلفة حسابياً
 * @param callback الدالة المراد تأخير تنفيذها
 * @param delay مدة التأخير بالمللي ثانية
 * @returns الدالة المؤخرة
 */
export function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
}

/**
 * Hook مخصص لتحسين أداء قوائم العناصر الكبيرة
 * @param items قائمة العناصر
 * @param itemHeight ارتفاع العنصر الواحد
 * @param visibleItems عدد العناصر المرئية
 * @returns العناصر المرئية فقط
 */
export function useVirtualizedList<T>(
  items: T[],
  itemHeight: number,
  visibleItems: number
): { virtualItems: T[]; totalHeight: number; startIndex: number } {
  const [scrollTop, setScrollTop] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollTop(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const startIndex = Math.max(0, Math.floor(scrollTop / itemHeight) - 5);
  const endIndex = Math.min(items.length, startIndex + visibleItems + 10);

  const virtualItems = useMemo(
    () => items.slice(startIndex, endIndex),
    [items, startIndex, endIndex]
  );

  const totalHeight = items.length * itemHeight;

  return { virtualItems, totalHeight, startIndex };
}
