/**
 * مكون React لدعم تعدد اللغات
 * يوفر واجهة لترجمة النصوص وتغيير اللغة
 */
import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// أنواع اللغات المدعومة
type Language = 'ar' | 'en';

// واجهة سياق اللغة
interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  dir: 'rtl' | 'ltr';
}

// إنشاء سياق اللغة
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// ترجمات التطبيق
const translations = {
  ar: {
    'app.title': 'معارف',
    'app.description': 'منصة تعليمية متكاملة',
    'nav.home': 'الرئيسية',
    'nav.members': 'الأعضاء',
    'nav.attendance': 'الحضور',
    'nav.activities': 'الأنشطة',
    'nav.messages': 'الرسائل',
    'nav.reports': 'التقارير',
    'nav.settings': 'الإعدادات',
    'nav.login': 'تسجيل الدخول',
    'nav.logout': 'تسجيل الخروج',
    'nav.dashboard': 'لوحة التحكم',
    'nav.students': 'الطلاب',
    'nav.groups': 'المجموعات',
    'button.save': 'حفظ',
    'button.cancel': 'إلغاء',
    'button.edit': 'تعديل',
    'button.delete': 'حذف',
    'button.add': 'إضافة',
    'form.name': 'الاسم',
    'form.email': 'البريد الإلكتروني',
    'form.password': 'كلمة المرور',
    'form.phone': 'رقم الهاتف',
    'form.role': 'الدور',
    'form.status': 'الحالة',
    'form.type': 'النوع',
    'form.date': 'التاريخ',
    'form.time': 'الوقت',
    'form.location': 'الموقع',
    'form.title': 'العنوان',
    'form.description': 'الوصف',
    'form.submit': 'إرسال',
    'settings.theme': 'السمة',
    'settings.language': 'اللغة',
    'settings.notifications': 'الإشعارات',
    'theme.light': 'فاتح',
    'theme.dark': 'داكن',
    'theme.system': 'النظام',
    'language.ar': 'العربية',
    'language.en': 'الإنجليزية',
    'error.required': 'هذا الحقل مطلوب',
    'error.email': 'البريد الإلكتروني غير صالح',
    'error.password': 'كلمة المرور يجب أن تكون 8 أحرف على الأقل',
    'error.phone': 'رقم الهاتف غير صالح',
    'error.server': 'حدث خطأ في الخادم',
    'error.notFound': 'الصفحة غير موجودة',
    'error.unauthorized': 'غير مصرح لك بالوصول',
    'success.save': 'تم الحفظ بنجاح',
    'success.delete': 'تم الحذف بنجاح',
    'success.update': 'تم التحديث بنجاح',
    'success.create': 'تم الإنشاء بنجاح',
    'confirm.delete': 'هل أنت متأكد من الحذف؟',
    'confirm.logout': 'هل أنت متأكد من تسجيل الخروج؟',
  },
  en: {
    'app.title': 'Mararf',
    'app.description': 'Integrated Educational Platform',
    'nav.home': 'Home',
    'nav.members': 'Members',
    'nav.attendance': 'Attendance',
    'nav.activities': 'Activities',
    'nav.messages': 'Messages',
    'nav.reports': 'Reports',
    'nav.settings': 'Settings',
    'nav.login': 'Login',
    'nav.logout': 'Logout',
    'nav.dashboard': 'Dashboard',
    'nav.students': 'Students',
    'nav.groups': 'Groups',
    'button.save': 'Save',
    'button.cancel': 'Cancel',
    'button.edit': 'Edit',
    'button.delete': 'Delete',
    'button.add': 'Add',
    'form.name': 'Name',
    'form.email': 'Email',
    'form.password': 'Password',
    'form.phone': 'Phone',
    'form.role': 'Role',
    'form.status': 'Status',
    'form.type': 'Type',
    'form.date': 'Date',
    'form.time': 'Time',
    'form.location': 'Location',
    'form.title': 'Title',
    'form.description': 'Description',
    'form.submit': 'Submit',
    'settings.theme': 'Theme',
    'settings.language': 'Language',
    'settings.notifications': 'Notifications',
    'theme.light': 'Light',
    'theme.dark': 'Dark',
    'theme.system': 'System',
    'language.ar': 'Arabic',
    'language.en': 'English',
    'error.required': 'This field is required',
    'error.email': 'Invalid email',
    'error.password': 'Password must be at least 8 characters',
    'error.phone': 'Invalid phone number',
    'error.server': 'Server error',
    'error.notFound': 'Page not found',
    'error.unauthorized': 'Unauthorized access',
    'success.save': 'Saved successfully',
    'success.delete': 'Deleted successfully',
    'success.update': 'Updated successfully',
    'success.create': 'Created successfully',
    'confirm.delete': 'Are you sure you want to delete?',
    'confirm.logout': 'Are you sure you want to logout?',
  },
};

// مزود سياق اللغة
export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  // استخدام اللغة المخزنة في localStorage أو اللغة الافتراضية (العربية)
  const [language, setLanguage] = useState<Language>(() => {
    const savedLanguage = localStorage.getItem('language') as Language;
    return savedLanguage || 'ar';
  });

  // تحديث اتجاه الصفحة عند تغيير اللغة
  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
    localStorage.setItem('language', language);
  }, [language]);

  // دالة الترجمة
  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  // اتجاه النص حسب اللغة
  const dir = language === 'ar' ? 'rtl' : 'ltr';

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, dir }}>
      {children}
    </LanguageContext.Provider>
  );
};

// Hook مخصص لاستخدام سياق اللغة
export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
