/**
 * مكون React لدعم وضع الظلام (Dark Mode)
 * يوفر واجهة لتغيير سمة التطبيق
 */
import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// أنواع السمات المدعومة
type Theme = 'light' | 'dark' | 'system';

// واجهة سياق السمة
interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  isDark: boolean;
}

// إنشاء سياق السمة
const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

// مزود سياق السمة
export const ThemeProvider = ({ children }: { children: ReactNode }) => {
  // استخدام السمة المخزنة في localStorage أو السمة الافتراضية (النظام)
  const [theme, setTheme] = useState<Theme>(() => {
    const savedTheme = localStorage.getItem('theme') as Theme;
    return savedTheme || 'system';
  });

  // تحديد ما إذا كانت السمة الحالية داكنة
  const [isDark, setIsDark] = useState<boolean>(false);

  // تحديث السمة عند تغييرها
  useEffect(() => {
    const root = window.document.documentElement;
    
    // إزالة جميع فئات السمة
    root.classList.remove('light', 'dark');
    
    // تحديد السمة المناسبة
    if (theme === 'system') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      root.classList.add(systemTheme);
      setIsDark(systemTheme === 'dark');
    } else {
      root.classList.add(theme);
      setIsDark(theme === 'dark');
    }
    
    // تخزين السمة في localStorage
    localStorage.setItem('theme', theme);
  }, [theme]);

  // الاستماع لتغييرات سمة النظام
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    const handleChange = () => {
      if (theme === 'system') {
        const systemTheme = mediaQuery.matches ? 'dark' : 'light';
        const root = window.document.documentElement;
        root.classList.remove('light', 'dark');
        root.classList.add(systemTheme);
        setIsDark(systemTheme === 'dark');
      }
    };
    
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme, isDark }}>
      {children}
    </ThemeContext.Provider>
  );
};

// Hook مخصص لاستخدام سياق السمة
export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
