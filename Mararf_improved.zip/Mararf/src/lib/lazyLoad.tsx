/**
 * مكون React لتطبيق Code Splitting وتحسين الأداء
 * يوفر واجهة لتحميل المكونات بشكل كسول (lazy loading)
 */
import { lazy, Suspense, ComponentType } from 'react';

interface LazyLoadProps {
  children: React.ReactNode;
}

// مكون تحميل مؤقت موحد للتطبيق
export const LoadingFallback = () => (
  <div className="flex items-center justify-center min-h-screen">
    <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-emerald-500"></div>
  </div>
);

// مكون لتغليف المكونات المحملة بشكل كسول
export const LazyLoad = ({ children }: LazyLoadProps) => {
  return <Suspense fallback={<LoadingFallback />}>{children}</Suspense>;
};

// دالة مساعدة لتحميل المكونات بشكل كسول
export function lazyImport<T extends ComponentType<any>, I extends { [K in N]: T }, N extends string>(
  factory: () => Promise<I>,
  name: N
): I {
  return Object.create({
    [name]: lazy(() => factory().then((module) => ({ default: module[name] }))),
  });
}

// دالة مساعدة لتحميل الصفحات بشكل كسول
export function lazyPage(importFunc: () => Promise<any>) {
  const LazyComponent = lazy(importFunc);
  return (props: any) => (
    <Suspense fallback={<LoadingFallback />}>
      <LazyComponent {...props} />
    </Suspense>
  );
}
