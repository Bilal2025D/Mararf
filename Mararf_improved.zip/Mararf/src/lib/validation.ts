/**
 * مكون React لتحسين الأمان وتحقق من المدخلات
 * يستخدم مكتبة Zod للتحقق من صحة البيانات
 */
import { z } from 'zod';

// تعريف مخططات التحقق من البيانات

// مخطط التحقق من بيانات المستخدم
export const userSchema = z.object({
  name: z.string().min(3, { message: 'الاسم يجب أن يكون 3 أحرف على الأقل' }),
  email: z.string().email({ message: 'البريد الإلكتروني غير صالح' }),
  password: z.string().min(8, { message: 'كلمة المرور يجب أن تكون 8 أحرف على الأقل' })
    .regex(/[A-Z]/, { message: 'كلمة المرور يجب أن تحتوي على حرف كبير واحد على الأقل' })
    .regex(/[0-9]/, { message: 'كلمة المرور يجب أن تحتوي على رقم واحد على الأقل' }),
  role: z.enum(['admin', 'teacher', 'student', 'parent'], {
    errorMap: () => ({ message: 'الدور غير صالح' })
  })
});

// مخطط التحقق من بيانات الطالب
export const studentSchema = z.object({
  name: z.string().min(3, { message: 'الاسم يجب أن يكون 3 أحرف على الأقل' }),
  group: z.string().optional(),
  grade: z.string().optional(),
  parent_phone: z.string().regex(/^[0-9+]{10,15}$/, { 
    message: 'رقم الهاتف غير صالح' 
  }).optional()
});

// مخطط التحقق من بيانات الحضور
export const attendanceSchema = z.object({
  id: z.number(),
  name: z.string(),
  status: z.enum(['present', 'absent', 'late'], {
    errorMap: () => ({ message: 'حالة الحضور غير صالحة' })
  }),
  type: z.enum(['عضو', 'طالب', 'teacher', 'student'], {
    errorMap: () => ({ message: 'نوع المستخدم غير صالح' })
  })
});

// مخطط التحقق من بيانات النشاط
export const activitySchema = z.object({
  title: z.string().min(3, { message: 'العنوان يجب أن يكون 3 أحرف على الأقل' }),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, { message: 'التاريخ غير صالح' }),
  time: z.string().regex(/^\d{2}:\d{2}$/, { message: 'الوقت غير صالح' }),
  location: z.string().min(3, { message: 'الموقع يجب أن يكون 3 أحرف على الأقل' })
});

// مخطط التحقق من بيانات الإعدادات
export const settingsSchema = z.object({
  theme: z.enum(['light', 'dark', 'system'], {
    errorMap: () => ({ message: 'السمة غير صالحة' })
  }),
  language: z.enum(['ar', 'en'], {
    errorMap: () => ({ message: 'اللغة غير صالحة' })
  }),
  notifications: z.boolean()
});

/**
 * دالة للتحقق من صحة البيانات
 * @param schema مخطط التحقق
 * @param data البيانات المراد التحقق منها
 * @returns نتيجة التحقق
 */
export function validateData<T>(schema: z.ZodType<T>, data: unknown): { 
  success: boolean; 
  data?: T; 
  errors?: z.ZodError 
} {
  try {
    const validData = schema.parse(data);
    return { success: true, data: validData };
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { success: false, errors: error };
    }
    throw error;
  }
}

/**
 * دالة لتنظيف البيانات من أي محتوى ضار
 * @param input النص المراد تنظيفه
 * @returns النص بعد التنظيف
 */
export function sanitizeInput(input: string): string {
  return input
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
