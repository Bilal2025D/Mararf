/**
 * مكون الشريط العلوي المحسن
 * يتضمن دعم تعدد اللغات ووضع الظلام
 */
import { useState } from "react";
import { Link } from "react-router-dom";
import { useLanguage } from "@/contexts_merged/LanguageContext";
import { LanguageSwitcher } from "@/components/common/LanguageSwitcher";
import { ThemeSwitcher } from "@/components/common/ThemeSwitcher";
import { Button } from "@/components/ui/button";
import { 
  Menu, 
  X, 
  Home, 
  Users, 
  Calendar, 
  Activity, 
  MessageSquare, 
  FileText, 
  Settings 
} from "lucide-react";

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { t, dir } = useLanguage();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className={`bg-white dark:bg-gray-900 shadow-md ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link to="/" className="text-emerald-600 dark:text-emerald-400 font-bold text-xl">
                {t('app.title')}
              </Link>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <Link to="/" className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-white hover:border-gray-300">
                <Home className="h-4 w-4 mr-1" />
                {t('nav.home')}
              </Link>
              <Link to="/members" className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-white hover:border-gray-300">
                <Users className="h-4 w-4 mr-1" />
                {t('nav.members')}
              </Link>
              <Link to="/attendance" className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-white hover:border-gray-300">
                <Calendar className="h-4 w-4 mr-1" />
                {t('nav.attendance')}
              </Link>
              <Link to="/activities" className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-white hover:border-gray-300">
                <Activity className="h-4 w-4 mr-1" />
                {t('nav.activities')}
              </Link>
              <Link to="/messages" className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-white hover:border-gray-300">
                <MessageSquare className="h-4 w-4 mr-1" />
                {t('nav.messages')}
              </Link>
              <Link to="/reports" className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-white hover:border-gray-300">
                <FileText className="h-4 w-4 mr-1" />
                {t('nav.reports')}
              </Link>
              <Link to="/settings" className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-white hover:border-gray-300">
                <Settings className="h-4 w-4 mr-1" />
                {t('nav.settings')}
              </Link>
            </div>
          </div>
          <div className="hidden sm:ml-6 sm:flex sm:items-center sm:space-x-4">
            <ThemeSwitcher />
            <LanguageSwitcher />
            <Button variant="default" className="bg-emerald-600 hover:bg-emerald-700">
              {t('nav.login')}
            </Button>
          </div>
          <div className="-mr-2 flex items-center sm:hidden">
            <Button variant="ghost" onClick={toggleMenu} className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-emerald-500">
              <span className="sr-only">{isMenuOpen ? 'Close menu' : 'Open menu'}</span>
              {isMenuOpen ? (
                <X className="block h-6 w-6" aria-hidden="true" />
              ) : (
                <Menu className="block h-6 w-6" aria-hidden="true" />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1">
            <Link to="/" className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-gray-300 hover:text-gray-800">
              <Home className="inline-block h-4 w-4 mr-2" />
              {t('nav.home')}
            </Link>
            <Link to="/members" className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-gray-300 hover:text-gray-800">
              <Users className="inline-block h-4 w-4 mr-2" />
              {t('nav.members')}
            </Link>
            <Link to="/attendance" className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-gray-300 hover:text-gray-800">
              <Calendar className="inline-block h-4 w-4 mr-2" />
              {t('nav.attendance')}
            </Link>
            <Link to="/activities" className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-gray-300 hover:text-gray-800">
              <Activity className="inline-block h-4 w-4 mr-2" />
              {t('nav.activities')}
            </Link>
            <Link to="/messages" className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-gray-300 hover:text-gray-800">
              <MessageSquare className="inline-block h-4 w-4 mr-2" />
              {t('nav.messages')}
            </Link>
            <Link to="/reports" className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-gray-300 hover:text-gray-800">
              <FileText className="inline-block h-4 w-4 mr-2" />
              {t('nav.reports')}
            </Link>
            <Link to="/settings" className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-gray-300 hover:text-gray-800">
              <Settings className="inline-block h-4 w-4 mr-2" />
              {t('nav.settings')}
            </Link>
          </div>
          <div className="pt-4 pb-3 border-t border-gray-200 dark:border-gray-700">
            <div className="flex items-center px-4 space-x-4">
              <ThemeSwitcher />
              <LanguageSwitcher />
            </div>
            <div className="mt-3 space-y-1">
              <Button variant="default" className="w-full bg-emerald-600 hover:bg-emerald-700">
                {t('nav.login')}
              </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
