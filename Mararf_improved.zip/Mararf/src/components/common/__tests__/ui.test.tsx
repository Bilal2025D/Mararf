/**
 * اختبارات لمكونات واجهة المستخدم
 * يستخدم React Testing Library لاختبار المكونات
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { LanguageSwitcher } from '@/components/common/LanguageSwitcher';
import { ThemeSwitcher } from '@/components/common/ThemeSwitcher';
import { LanguageProvider, useLanguage } from '@/contexts_merged/LanguageContext';
import { ThemeProvider, useTheme } from '@/contexts_merged/ThemeContext';

// Mock للـ hooks
vi.mock('@/contexts_merged/LanguageContext', async () => {
  const actual = await vi.importActual('@/contexts_merged/LanguageContext');
  return {
    ...actual,
    useLanguage: vi.fn(),
  };
});

vi.mock('@/contexts_merged/ThemeContext', async () => {
  const actual = await vi.importActual('@/contexts_merged/ThemeContext');
  return {
    ...actual,
    useTheme: vi.fn(),
  };
});

describe('LanguageSwitcher', () => {
  it('should render language switcher button', () => {
    // Mock لـ useLanguage
    vi.mocked(useLanguage).mockReturnValue({
      language: 'ar',
      setLanguage: vi.fn(),
      t: (key) => key,
      dir: 'rtl',
    });

    render(<LanguageSwitcher />);
    
    // التحقق من وجود زر تبديل اللغة
    const button = screen.getByRole('button');
    expect(button).toBeInTheDocument();
  });

  it('should toggle language when clicked', () => {
    // Mock لدالة تغيير اللغة
    const setLanguageMock = vi.fn();
    
    // Mock لـ useLanguage
    vi.mocked(useLanguage).mockReturnValue({
      language: 'ar',
      setLanguage: setLanguageMock,
      t: (key) => key,
      dir: 'rtl',
    });

    render(<LanguageSwitcher />);
    
    // النقر على زر تبديل اللغة
    const button = screen.getByRole('button');
    fireEvent.click(button);
    
    // التحقق من استدعاء دالة تغيير اللغة
    expect(setLanguageMock).toHaveBeenCalledWith('en');
  });
});

describe('ThemeSwitcher', () => {
  it('should render theme switcher button', () => {
    // Mock لـ useTheme
    vi.mocked(useTheme).mockReturnValue({
      theme: 'light',
      setTheme: vi.fn(),
      isDark: false,
    });
    
    // Mock لـ useLanguage
    vi.mocked(useLanguage).mockReturnValue({
      language: 'ar',
      setLanguage: vi.fn(),
      t: (key) => key,
      dir: 'rtl',
    });

    render(<ThemeSwitcher />);
    
    // التحقق من وجود زر تبديل السمة
    const button = screen.getByRole('button');
    expect(button).toBeInTheDocument();
  });

  it('should toggle theme when clicked', () => {
    // Mock لدالة تغيير السمة
    const setThemeMock = vi.fn();
    
    // Mock لـ useTheme
    vi.mocked(useTheme).mockReturnValue({
      theme: 'light',
      setTheme: setThemeMock,
      isDark: false,
    });
    
    // Mock لـ useLanguage
    vi.mocked(useLanguage).mockReturnValue({
      language: 'ar',
      setLanguage: vi.fn(),
      t: (key) => key,
      dir: 'rtl',
    });

    render(<ThemeSwitcher />);
    
    // النقر على زر تبديل السمة
    const button = screen.getByRole('button');
    fireEvent.click(button);
    
    // التحقق من استدعاء دالة تغيير السمة
    expect(setThemeMock).toHaveBeenCalledWith('dark');
  });
});

describe('LanguageProvider', () => {
  it('should provide language context to children', () => {
    // مكون اختبار لاستخدام سياق اللغة
    const TestComponent = () => {
      const { language } = useLanguage();
      return <div data-testid="language-value">{language}</div>;
    };
    
    // Mock لـ useLanguage للسماح باستخدامه في TestComponent
    const originalUseLanguage = vi.mocked(useLanguage);
    vi.mocked(useLanguage).mockImplementation(() => {
      return {
        language: 'ar',
        setLanguage: vi.fn(),
        t: (key) => key,
        dir: 'rtl',
      };
    });

    render(
      <LanguageProvider>
        <TestComponent />
      </LanguageProvider>
    );
    
    // التحقق من قيمة اللغة
    const languageValue = screen.getByTestId('language-value');
    expect(languageValue.textContent).toBe('ar');
    
    // إعادة Mock الأصلي
    vi.mocked(useLanguage).mockImplementation(originalUseLanguage);
  });
});

describe('ThemeProvider', () => {
  it('should provide theme context to children', () => {
    // مكون اختبار لاستخدام سياق السمة
    const TestComponent = () => {
      const { theme } = useTheme();
      return <div data-testid="theme-value">{theme}</div>;
    };
    
    // Mock لـ useTheme للسماح باستخدامه في TestComponent
    const originalUseTheme = vi.mocked(useTheme);
    vi.mocked(useTheme).mockImplementation(() => {
      return {
        theme: 'light',
        setTheme: vi.fn(),
        isDark: false,
      };
    });

    render(
      <ThemeProvider>
        <TestComponent />
      </ThemeProvider>
    );
    
    // التحقق من قيمة السمة
    const themeValue = screen.getByTestId('theme-value');
    expect(themeValue.textContent).toBe('light');
    
    // إعادة Mock الأصلي
    vi.mocked(useTheme).mockImplementation(originalUseTheme);
  });
});
