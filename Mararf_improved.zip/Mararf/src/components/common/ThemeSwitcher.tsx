/**
 * مكون واجهة المستخدم لتبديل السمة
 * يوفر زر لتغيير سمة التطبيق بين الوضع الفاتح والداكن
 */
import { useTheme } from "@/contexts_merged/ThemeContext";
import { useLanguage } from "@/contexts_merged/LanguageContext";
import { Button } from "@/components/ui/button";
import { Moon, Sun } from "lucide-react";

export function ThemeSwitcher() {
  const { theme, setTheme, isDark } = useTheme();
  const { t } = useLanguage();

  const toggleTheme = () => {
    setTheme(isDark ? 'light' : 'dark');
  };

  return (
    <Button
      variant="outline"
      size="icon"
      onClick={toggleTheme}
      title={t('settings.theme')}
      className="rounded-full"
    >
      {isDark ? (
        <Sun className="h-4 w-4" />
      ) : (
        <Moon className="h-4 w-4" />
      )}
      <span className="sr-only">{t('settings.theme')}</span>
    </Button>
  );
}
