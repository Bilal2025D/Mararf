/**
 * مكون واجهة المستخدم لتبديل اللغة
 * يوفر زر لتغيير لغة التطبيق
 */
import { useLanguage } from "@/contexts_merged/LanguageContext";
import { Button } from "@/components/ui/button";
import { Languages } from "lucide-react";

export function LanguageSwitcher() {
  const { language, setLanguage, t } = useLanguage();

  const toggleLanguage = () => {
    setLanguage(language === 'ar' ? 'en' : 'ar');
  };

  return (
    <Button
      variant="outline"
      size="icon"
      onClick={toggleLanguage}
      title={t('settings.language')}
      className="rounded-full"
    >
      <Languages className="h-4 w-4" />
      <span className="sr-only">{t('settings.language')}</span>
    </Button>
  );
}
