/**
 * تكوين أمان Supabase
 * يوفر واجهة آمنة للتعامل مع قاعدة البيانات
 */
import { createClient } from '@supabase/supabase-js';
import { validateData } from './validation';
import { z } from 'zod';

// إنشاء عميل Supabase مع التحقق من وجود المتغيرات البيئية
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('متغيرات بيئة Supabase غير محددة');
}

// إنشاء عميل Supabase
export const supabase = createClient(supabaseUrl, supabaseKey);

/**
 * دالة آمنة لإدراج بيانات في جدول
 * @param table اسم الجدول
 * @param schema مخطط التحقق من البيانات
 * @param data البيانات المراد إدراجها
 * @returns نتيجة العملية
 */
export async function safeInsert<T>(
  table: string,
  schema: z.ZodType<T>,
  data: unknown
) {
  // التحقق من صحة البيانات قبل الإدراج
  const validation = validateData(schema, data);
  
  if (!validation.success) {
    return {
      success: false,
      error: validation.errors,
      data: null
    };
  }
  
  try {
    const { data: result, error } = await supabase
      .from(table)
      .insert(validation.data)
      .select();
      
    if (error) {
      return {
        success: false,
        error,
        data: null
      };
    }
    
    return {
      success: true,
      error: null,
      data: result
    };
  } catch (error) {
    return {
      success: false,
      error,
      data: null
    };
  }
}

/**
 * دالة آمنة لتحديث بيانات في جدول
 * @param table اسم الجدول
 * @param schema مخطط التحقق من البيانات
 * @param id معرف السجل المراد تحديثه
 * @param data البيانات المراد تحديثها
 * @returns نتيجة العملية
 */
export async function safeUpdate<T>(
  table: string,
  schema: z.ZodType<T>,
  id: string | number,
  data: unknown
) {
  // التحقق من صحة البيانات قبل التحديث
  const validation = validateData(schema, data);
  
  if (!validation.success) {
    return {
      success: false,
      error: validation.errors,
      data: null
    };
  }
  
  try {
    const { data: result, error } = await supabase
      .from(table)
      .update(validation.data)
      .eq('id', id)
      .select();
      
    if (error) {
      return {
        success: false,
        error,
        data: null
      };
    }
    
    return {
      success: true,
      error: null,
      data: result
    };
  } catch (error) {
    return {
      success: false,
      error,
      data: null
    };
  }
}

/**
 * دالة آمنة لاسترجاع بيانات من جدول
 * @param table اسم الجدول
 * @param query استعلام اختياري
 * @returns نتيجة العملية
 */
export async function safeSelect(
  table: string,
  query?: {
    column?: string;
    value?: string | number;
    limit?: number;
    order?: { column: string; ascending: boolean };
  }
) {
  try {
    let queryBuilder = supabase.from(table).select('*');
    
    if (query?.column && query?.value !== undefined) {
      queryBuilder = queryBuilder.eq(query.column, query.value);
    }
    
    if (query?.limit) {
      queryBuilder = queryBuilder.limit(query.limit);
    }
    
    if (query?.order) {
      queryBuilder = queryBuilder.order(
        query.order.column,
        { ascending: query.order.ascending }
      );
    }
    
    const { data, error } = await queryBuilder;
    
    if (error) {
      return {
        success: false,
        error,
        data: null
      };
    }
    
    return {
      success: true,
      error: null,
      data
    };
  } catch (error) {
    return {
      success: false,
      error,
      data: null
    };
  }
}

/**
 * دالة آمنة لحذف بيانات من جدول
 * @param table اسم الجدول
 * @param id معرف السجل المراد حذفه
 * @returns نتيجة العملية
 */
export async function safeDelete(
  table: string,
  id: string | number
) {
  try {
    const { data, error } = await supabase
      .from(table)
      .delete()
      .eq('id', id)
      .select();
      
    if (error) {
      return {
        success: false,
        error,
        data: null
      };
    }
    
    return {
      success: true,
      error: null,
      data
    };
  } catch (error) {
    return {
      success: false,
      error,
      data: null
    };
  }
}
